package com.uwuwiets.keyboard

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class UwUKeyboardView(
    context: Context,
    private val onInput: (String) -> Unit
) : View(context) {
    private data class Key(val label: String, val x: Float, val y: Float, val w: Float, val h: Float, val action: String = label)
    private data class Ripple(val x: Float, val y: Float, val start: Long, val keyIndex: Int)
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ripples = mutableListOf<Ripple>()
    private var keys = emptyList<Key>()
    private var downIndex = -1
    private var shifted = false
    private var symbols = false
    private var lastFrame = 0L

    private fun dp(v: Float) = v * density

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, dp(286f).toInt())
    }

    private fun buildKeys() {
        val width = width.toFloat()
        val gap = dp(5f)
        val side = dp(7f)
        val keyH = dp(49f)
        val rowGap = dp(9f)
        val rows = if (symbols) listOf(
            listOf("1","2","3","4","5","6","7","8","9","0"),
            listOf("@","#","$","%","&","-","+","(",")","/"),
            listOf("=", "*", """, "'", ":", ";", "!", "?", "⌫"),
            listOf("ABC","🌐",",","space",".","↵")
        ) else listOf(
            (if (shifted) "QWERTYUIOP" else "qwertyuiop").map { it.toString() },
            (if (shifted) "ASDFGHJKL" else "asdfghjkl").map { it.toString() },
            listOf("⇧") + (if (shifted) "ZXCVBNM" else "zxcvbnm").map { it.toString() } + "⌫",
            listOf("?123","🌐",",","space",".","↵")
        )
        val result = mutableListOf<Key>()
        rows.forEachIndexed { row, labels ->
            val y = dp(9f) + row * (keyH + rowGap)
            val available = width - side * 2 - gap * (labels.size - 1)
            val unit = available / labels.size
            var x = side
            labels.forEachIndexed { index, label ->
                var factor = 1f
                if (row == 3) factor = when (label) { "space" -> 3.4f; "?123","ABC","↵" -> 1.35f; else -> 1f }
                val w = if (row == 3) unit * factor else unit
                result.add(Key(label, x, y, w, keyH, when (label) {
                    "space" -> " "
                    "?123" -> "?123"
                    "ABC" -> "ABC"
                    else -> label
                }))
                x += w + gap
            }
        }
        keys = result
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        buildKeys()
        canvas.drawColor(Color.rgb(9, 9, 11))
        val now = SystemClock.uptimeMillis()
        val iterator = ripples.iterator()
        while (iterator.hasNext()) {
            val r = iterator.next()
            val t = ((now - r.start) / 650f).coerceIn(0f, 1f)
            val key = keys.getOrNull(r.keyIndex)
            if (key != null) {
                val cx = key.x + key.w / 2f
                val cy = key.y + key.h / 2f
                val radius = dp(8f) + dp(66f) * (1f - (1f - t).pow(3))
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = dp(1.4f) * (1f - t)
                paint.color = Color.argb((75 * (1f - t)).toInt(), 220, 225, 235)
                canvas.drawCircle(cx, cy, radius, paint)
                paint.style = Paint.Style.FILL
            }
            if (t >= 1f) iterator.remove()
        }

        keys.forEachIndexed { index, key ->
            val active = ripples.lastOrNull { it.keyIndex == index }
            val t = active?.let { ((now - it.start) / 650f).coerceIn(0f, 1f) } ?: 1f
            val press = if (active != null) sin(t * Math.PI).toFloat() else 0f
            val inset = dp(1f)
            val rect = RectF(key.x + inset, key.y + inset + dp(3f) * press,
                key.x + key.w - inset, key.y + key.h - inset + dp(3f) * press)
            paint.setShadowLayer(dp(7f), 0f, dp(3f), Color.argb(65, 0, 0, 0))
            paint.shader = LinearGradient(rect.left, rect.top, rect.left, rect.bottom,
                intArrayOf(Color.rgb(42,42,47), Color.rgb(23,23,27), Color.rgb(17,17,20)),
                null, Shader.TileMode.CLAMP)
            canvas.drawRoundRect(rect, dp(11f), dp(11f), paint)
            paint.shader = null
            paint.clearShadowLayer()
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(0.7f)
            paint.color = Color.argb(55, 235, 238, 245)
            canvas.drawRoundRect(rect, dp(11f), dp(11f), paint)
            paint.style = Paint.Style.FILL
            val label = when (key.label) { "space" -> "English (US)"; else -> key.label }
            paint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = when (key.label) { "space" -> dp(10f); "🌐" -> dp(17f); else -> dp(19f) }
            paint.color = if (key.label in listOf("⇧","⌫","↵","?123","ABC")) Color.rgb(190,193,202) else Color.rgb(245,245,248)
            val textY = rect.centerY() - (paint.ascent() + paint.descent()) / 2f
            canvas.drawText(label, rect.centerX(), textY, paint)
        }
        if (ripples.isNotEmpty()) postInvalidateOnAnimation()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downIndex = keys.indexOfFirst { event.x >= it.x && event.x <= it.x + it.w && event.y >= it.y && event.y <= it.y + it.h }
                if (downIndex >= 0) {
                    val key = keys[downIndex]
                    ripples.add(Ripple(event.x, event.y, SystemClock.uptimeMillis(), downIndex))
                    if (ripples.size > 18) ripples.removeAt(0)
                    when (key.label) {
                        "⇧" -> shifted = !shifted
                        "?123" -> symbols = true
                        "ABC" -> symbols = false
                        "space" -> onInput(" ")
                        "🌐" -> { /* language switch placeholder */ }
                        else -> {
                            onInput(key.action)
                            if (shifted && key.label.length == 1) shifted = false
                        }
                    }
                    performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                downIndex = -1
                invalidate()
                return true
            }
        }
        return true
    }
}
