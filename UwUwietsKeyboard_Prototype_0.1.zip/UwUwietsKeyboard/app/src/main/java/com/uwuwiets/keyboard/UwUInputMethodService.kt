package com.uwuwiets.keyboard

import android.inputmethodservice.InputMethodService
import android.view.View

class UwUInputMethodService : InputMethodService() {
    override fun onCreateInputView(): View {
        return UwUKeyboardView(this) { value ->
            val connection = currentInputConnection ?: return@UwUKeyboardView
            when (value) {
                "⌫" -> connection.deleteSurroundingText(1, 0)
                "↵" -> connection.commitText("\n", 1)
                "⇧" -> { /* shift is handled by the view */ }
                "🌐" -> requestShowSelf(0)
                else -> connection.commitText(value, 1)
            }
        }
    }
}
